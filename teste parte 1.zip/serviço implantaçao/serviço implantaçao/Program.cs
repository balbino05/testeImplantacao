﻿using System.ServiceProcess;
using System.Collections.Generic;

namespace DivisoresService
{
    public partial class DivisoresService : ServiceBase
    {
        public DivisoresService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            // Inicie o serviço aqui, por exemplo, configurando um timer para realizar cálculos periodicamente.
        }

        protected override void OnStop()
        {
            // Pare o serviço aqui.
        }

        private List<int> CalcularDivisores(int numero)
        {
            List<int> divisores = new List<int>();
            for (int i = 1; i <= numero; i++)
            {
                if (numero % i == 0)
                {
                    divisores.Add(i);
                }
            }
            return divisores;
        }

        private List<int> CalcularDivisoresPrimos(List<int> divisores)
        {
            List<int> divisoresPrimos = new List<int>();
            foreach (var divisor in divisores)
            {
                if (EhPrimo(divisor))
                {
                    divisoresPrimos.Add(divisor);
                }
            }
            return divisoresPrimos;
        }

        private bool EhPrimo(int numero)
        {
            if (numero <= 1)
            {
                return false;
            }
            for (int i = 2; i * i <= numero; i++)
            {
                if (numero % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
